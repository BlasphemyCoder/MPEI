function p = f(x)
    p = (x + 5)/30;
end

